-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Мар 03 2017 г., 20:09
-- Версия сервера: 10.1.21-MariaDB
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `region`
--

-- --------------------------------------------------------

--
-- Структура таблицы `fonds`
--

CREATE TABLE `fonds` (
  `id` int(11) NOT NULL,
  `regNumber` varchar(64) DEFAULT NULL COMMENT 'регистрационный номер',
  `name` varchar(128) DEFAULT NULL COMMENT 'название организации',
  `date` date NOT NULL COMMENT 'дата',
  `sca` float(14,2) NOT NULL DEFAULT '0.00' COMMENT 'сча',
  `enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'активен=true, неактивен=false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='таблица с фондами' ROW_FORMAT=DYNAMIC;

--
-- Дамп данных таблицы `fonds`
--

INSERT INTO `fonds` (`id`, `regNumber`, `name`, `date`, `sca`, `enabled`) VALUES
(1, '1111-2222-333', 'ТЕСТ ПО-РУССКИ 1', '2017-02-20', 9000000512.00, 1),
(3, '0120-14241368', '\"Открытый Паевой Инвестиционный Фонд акций \"РЕГИОН Фонд Акций\"', '2017-02-16', 58431256.00, 1),
(4, '0255-74113814', '\"Открытый Паевой Инвестиционный Фонд смешанных инвестиций \"РЕГИОН Фонд Сбалансированный\"', '2017-02-16', 7938740.50, 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `fonds`
--
ALTER TABLE `fonds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `regnumindex` (`regNumber`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `fonds`
--
ALTER TABLE `fonds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
